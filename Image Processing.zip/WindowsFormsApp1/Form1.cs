﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;



namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        
        Bitmap loaded;
        Bitmap processed;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            if(op.ShowDialog() == DialogResult.OK)
            {
                Image img = Image.FromFile(op.FileName);
                pictureBox1.Image = img;
                loaded = new Bitmap(img);
            }
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
                Color pixel;
                processed = new Bitmap(loaded.Width, loaded.Height);
                for (int x = 0; x < loaded.Width; x++)
                {
                    for (int y = 0; y < loaded.Height; y++)
                    {
                        pixel = loaded.GetPixel(x, y);
                        processed.SetPixel(x, y, pixel);
                    }
                }
                pictureBox2.Image = processed;
        }

        private void grayScaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Color pixel;
            int grey; 
            processed = new Bitmap(loaded.Width, loaded.Height);
            for(int x = 0; x < loaded.Width; x++)
            {
                for(int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    grey = (byte)((pixel.R + pixel.G + pixel.B) / 3);
                    processed.SetPixel(x,y,Color.FromArgb(grey, grey, grey));
                }
            }
            pictureBox2.Image = processed;
        }

        private void invertToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Color pixel;
            int grey;
            processed = new Bitmap(loaded.Width, loaded.Height);
            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    processed.SetPixel(x, y, Color.FromArgb(255-pixel.R, 255 - pixel.G, 255 - pixel.B));
                }
            }
            pictureBox2.Image = processed;
        }

        private void sepiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Color pixel;
            int a, r, g, b;
            processed = new Bitmap(loaded.Width, loaded.Height);
            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    a = pixel.A;
                    r = pixel.R;
                    g = pixel.G;
                    b = pixel.B;

                    int tr = (int)(0.393 * r + 0.769 * g + 0.189 * b);
                    int tg = (int)(0.349 * r + 0.686 * g + 0.168 * b);
                    int tb = (int)(0.272 * r + 0.534 * g + 0.131 * b);

                    
                    if (tr > 255)
                    {
                        r = 255;
                    }
                    else
                    {
                        r = tr;
                    }

                    if (tg > 255)
                    {
                        g = 255;
                    }
                    else
                    {
                        g = tg;
                    }

                    if (tb > 255)
                    {
                        b = 255;
                    }
                    else
                    {
                        b = tb;
                    }
                    processed.SetPixel(x, y, Color.FromArgb(a ,r, g, b));
                }
            }
            pictureBox2.Image = processed;


        }

        private void histogramToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (loaded == null)
            {
                MessageBox.Show("Please open an image first.");
                return;
            }

            Dictionary<string, List<int>> histograms = CalculateHistograms(loaded);

            DisplayHistograms(histograms);

        }

        private Dictionary<string, List<int>> CalculateHistograms(Bitmap image)
        {
            Dictionary<string, List<int>> histograms = new Dictionary<string, List<int>>();

            histograms["Red"] = new List<int>(new int[256]);
            histograms["Green"] = new List<int>(new int[256]);
            histograms["Blue"] = new List<int>(new int[256]);

            for (int x = 0; x < image.Width; x++)
            {
                for (int y = 0; y < image.Height; y++)
                {
                    Color pixel = image.GetPixel(x, y);
                    histograms["Red"][pixel.R]++;
                    histograms["Green"][pixel.G]++;
                    histograms["Blue"][pixel.B]++;
                }
            }

            return histograms;
        }

        private void DisplayHistograms(Dictionary<string, List<int>> histograms)
        {
            chart1.Series.Clear();

            Color colorRed = Color.Red;
            Color colorGreen = Color.Green;
            Color colorBlue = Color.Blue;

            foreach (string channel in histograms.Keys)
            {
                Series series = new Series(channel);
                series.ChartType = SeriesChartType.Column;
                series.Points.DataBindY(histograms[channel]);
                if (channel == "Red")
                    series.Color = colorRed;
                else if (channel == "Green")
                    series.Color = colorGreen;
                else if (channel == "Blue")
                    series.Color = colorBlue;
                series["PixelPointWidth"] = "23";
                chart1.Series.Add(series);
            }

            chart1.Titles.Clear();
            chart1.Titles.Add("Histogram");
            chart1.ChartAreas[0].AxisX.Title = "Pixel Value";
            chart1.ChartAreas[0].AxisY.Title = "Frequency";

            chart1.Visible = true;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
                if (pictureBox2.Image != null)
                {
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.Filter = "Image Files(*.jpeg;*.bmp;*.png;)|*.jpeg;*.bmp;*.png;";
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        pictureBox2.Image.Save(saveFileDialog.FileName);
                    }
                }
            
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

    }
}
